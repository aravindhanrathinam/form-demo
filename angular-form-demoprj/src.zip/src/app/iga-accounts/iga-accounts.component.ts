import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common'


@Component({
  selector: 'app-iga-accounts',
  templateUrl: './iga-accounts.component.html',
  styleUrls: ['./iga-accounts.component.css']
})
export class IgaAccountsComponent implements OnInit {
  cols = [
    { field: '', header: 'Account Number', width: '' },
    { field: '', header: 'Account Name', width: '' },
    { field: '', header: 'Account Region', width: '' },
    { field: '', header: 'Branch Code', width: '' },
    { field: '', header: 'Branch Name', width: '' },
    { field: '', header: 'Currency', width: '' },
    { field: '', header: 'Account Status', width: '' },
    { field: '', header: 'GID1', width: '' },
    { field: '', header: 'Company Name', width: '' },
    { field: '', header: 'PID', width: '' },
    { field: '', header: 'Parent Company Name', width: '' },
    { field: '', header: 'Region', width: '' },
  ];
  accounts: { Number: string; Name: string; ARegion: string; Code: string; bName: string; Currency: string; Status: string; GID1: string; cname: string; PID: string; pcname: string; region: string; }[];
  
  constructor(private location: Location) { }

  ngOnInit(): void {
    this.accounts=[
      {Number:'Ganesh',Name:'India',ARegion:'region',
      Code:'IDK',bName:'frontend',Currency:'Ganesh',Status:'India',
      GID1:'Wipro',cname:'IDK',PID:'frontend',pcname:'frontend',region:"india"}, 
    ]
  }
backNavigation(){
  this.location.back()
}
}
