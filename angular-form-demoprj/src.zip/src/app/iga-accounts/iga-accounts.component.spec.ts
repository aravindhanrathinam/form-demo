import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IgaAccountsComponent } from './iga-accounts.component';

describe('IgaAccountsComponent', () => {
  let component: IgaAccountsComponent;
  let fixture: ComponentFixture<IgaAccountsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IgaAccountsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IgaAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
