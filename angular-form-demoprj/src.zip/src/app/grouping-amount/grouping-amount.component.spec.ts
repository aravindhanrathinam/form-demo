import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupingAmountComponent } from './grouping-amount.component';

describe('GroupingAmountComponent', () => {
  let component: GroupingAmountComponent;
  let fixture: ComponentFixture<GroupingAmountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GroupingAmountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupingAmountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
