import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-grouping-amount',
  templateUrl: './grouping-amount.component.html',
  styleUrls: ['./grouping-amount.component.css']
})
export class GroupingAmountComponent implements OnInit {
  
  cols = [
    { field: '', header: '', width: '3%' },
    { field: '', header: 'Company Name', width: '15%' },
    { field: '', header: 'Cust ID', width: '15%' },
    { field: '', header: 'GID', width: '15%' },
    { field: '', header: 'Branch', width: '15%' },
    { field: '', header: 'No.of acct', width: '10%' },
    { field: '', header: '', width: '9%' },
  ];
    totalRecords: number;

   

    loading: boolean;



    selectAll: boolean = false;

  cities: { name: string; code: string; }[];
  representatives: { name: string; image: string; }[];
  customers: { name: string; country: string; company: string; representative: string; tech: string; }[];
  showSer: boolean;
  

  constructor(private router: Router) {
    
    this.cities = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
  ];
  this.customers=[
    {name:'Ganesh',country:'India',company:'Wipro',representative:'IDK',tech:'frontend'},
    
  ]
   }

  ngOnInit(): void {
    
  
  }
showSearch(){
  this.showSer=!this.showSer;
}
showAccountDetails(){
  this.router.navigate(['/igaAccounts'])
}
}
